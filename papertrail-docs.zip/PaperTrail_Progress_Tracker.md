# PaperTrail — Build Progress Tracker (Levels & Phases)
**Generated:** 2025-11-15T15:47:13.172892 UTC

> Use this document to report weekly. Each *Level* has entry/exit criteria, owners, dependencies, and a status RAG.

## Legend
- **Status:** ⬜ Not Started • 🟡 In Progress • 🟢 Done • 🔴 Blocked
- **RAG Health:** 🟢 On Track • 🟡 At Risk • 🔴 Off Track
- **Roles:** ENG (Engineering), FE (Frontend), BE (Backend), ML, UX, QA, DEVOPS, PM

---

## Snapshot (fill weekly)
| Week | Phase | Current Level | RAG | Notes |
|---|---|---|---|---|
| YYYY‑WW | Phase N | Lx | 🟢/🟡/🔴 | ... |

---

## Level 0 — Foundation & Environments
**Owners:** DEVOPS, ENG • **Target:** Week 2  
**Entry:** repo created; **Exit:** developers can run web/api/rag locally.

**Tasks**
- [ ] Repo + branching strategy documented
- [ ] Docker infra: Postgres, Redis, Neo4j, Qdrant
- [ ] Neon staging/prod set up; migrations harness
- [ ] Vercel (web) + ECS (api/rag) pipelines
- [ ] Secrets manager wired; `/healthz` checks

**Acceptance**
- [ ] One-click local bootstrap works (`docker compose up`)
- [ ] Preview deployments per PR auto‑build

**Status:** ⬜ | **Notes:** …

---

## Level 1 — Research‑Log MVP
**Owners:** FE, BE, UX, QA • **Target:** Week 4

**Tasks**
- [ ] Heatmap component (keyboard+SR)
- [ ] GraphQL `researchLog` wired to DB aggregation
- [ ] RP ledger aggregation by day
- [ ] Streak + Rest Days logic
- [ ] A11y checks (axe/Lighthouse)

**Acceptance**
- [ ] 52×7 heatmap navigable via keyboard
- [ ] RP totals match ledger for sampled users

**Status:** ⬜ | **Notes:** …

---

## Level 2 — Feed & Save
**Owners:** FE, BE, ML (features), QA • **Target:** Week 6

**Tasks**
- [ ] PaperCard + predictor bar
- [ ] `savePaper` action + interaction write
- [ ] Discovery features (content/network/collab/recency) cached in Redis
- [ ] Basic ranking pipeline skeleton
- [ ] Analytics events (`paper_saved`, clicks)

**Acceptance**
- [ ] ⌘/Ctrl+S works; predictor has SR text
- [ ] Ranking stable and paginated

**Status:** ⬜ | **Notes:** …

---

## Level 3 — Annotations (Private)
**Owners:** FE, BE, QA • **Target:** Week 8

**Tasks**
- [ ] Reader shell; `/api/v1/annotations` CRUD
- [ ] Visibility enforcement (`private` only)
- [ ] RP +5 on create
- [ ] Keyboard navigation within annotations

**Acceptance**
- [ ] Create/select/edit/delete works across browsers
- [ ] RP ledger entry created on annotate

**Status:** ⬜ | **Notes:** …

---

## Level 4 — Lab Streams (Internal + Public Read)
**Owners:** FE, BE, PM, QA • **Target:** Week 10

**Tasks**
- [ ] `stream_posts` auto on save/comment
- [ ] `/labs` directory + lab page
- [ ] Follow labs; free limit = 3
- [ ] Catalyst role + rate-limited manual post

**Acceptance**
- [ ] Stream renders and paginates
- [ ] Follow limit enforced for Free

**Status:** ⬜ | **Notes:** …

---

## Level 5 — Public Launch (Free Tier)
**Owners:** PM, ENG, QA, DEVOPS • **Target:** Week 16

**Tasks**
- [ ] Onboarding (launch field)
- [ ] Public comments (Catalysts only initially)
- [ ] A11y manual pass
- [ ] Observability dashboards

**Acceptance**
- [ ] Sign-ups → Research‑Log in < 5 min
- [ ] p95 API < 300 ms on key reads

**Status:** ⬜ | **Notes:** …

---

## Level 6 — Evidence Map (S2-only)
**Owners:** ML, BE, FE, QA • **Target:** Month 6

**Tasks**
- [ ] `/evidence` endpoint with S2 + OpenAlex
- [ ] Evidence list UI (10 items) with votes
- [ ] Vote persistence + analytics
- [ ] Prompt regression suite

**Acceptance**
- [ ] Precision@10 ≥ 0.7 on golden set
- [ ] Upvote rate ≥ 40% (beta cohort)

**Status:** ⬜ | **Notes:** …

---

## Level 7 — Pro Tier + Ask the Paper (RAG)
**Owners:** ML, BE, FE, PM • **Target:** Month 9

**Tasks**
- [ ] Pro billing + entitlements
- [ ] `/ask` endpoint; citations mandatory
- [ ] Rate limits & cost guards
- [ ] UXR on answer helpfulness

**Acceptance**
- [ ] 95% answers contain ≥2 valid citations
- [ ] Latency p95 ≤ 5s (cached if repeat)

**Status:** ⬜ | **Notes:** …

---

## Level 8 — Lab Tier (Reading Rooms)
**Owners:** PM, BE, FE • **Target:** Month 12

**Tasks**
- [ ] SSO + iframe auth with Partner
- [ ] Attendance event → +25 RP
- [ ] Transcript → Q&A binder
- [ ] PI Dashboard (heatmap + progress table)

**Acceptance**
- [ ] End-to-end attendance recorded
- [ ] PI sees weekly prep status

**Status:** ⬜ | **Notes:** …

---

## Level 9 — Institutional + API
**Owners:** PM, ENG, DEVOPS • **Target:** Month 18

**Tasks**
- [ ] SSO (SAML/OIDC) + SCIM (optional)
- [ ] Bulk analytics & export API
- [ ] Claim Tracker dashboard
- [ ] Privacy/Security review

**Acceptance**
- [ ] 2 pilot departments onboarded
- [ ] Data export SLA met

**Status:** ⬜ | **Notes:** …

---

## Rolling Risks & Decisions
| Date | Item | Type | Owner | Status | Notes |
|---|---|---|---|---|---|
| YYYY‑MM‑DD | ADR‑00X | Decision | PM | Open | ... |
| YYYY‑MM‑DD | “Empty Room” | Risk | PM | 🟡 | Catalyst throughput down |

---

**Reporting Template**
- **Phase/Level:** …
- **This week:** …
- **Risks/Blocks:** …
- **Next week:** …

**Checksum:** "6682d255daed1fa9481a7aac1b87cde71de75b4c51420760a4c91f631040e423"
