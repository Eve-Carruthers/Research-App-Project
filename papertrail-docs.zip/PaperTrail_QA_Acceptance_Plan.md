# PaperTrail — QA & Acceptance Test Plan
**Generated:** 2025-11-15T15:47:13.172892 UTC

## 1. Scope & Strategy
Covers unit, contract, integration, E2E, accessibility, performance, security, and AI/RAG evaluation. Acceptance is per-module DoD and per-level exit criteria (see Progress Tracker).

## 2. Test Environments
- **Local Dev:** feature branches
- **Staging:** PR previews (Vercel web + Neon branch DB)
- **Production:** blue/green, health checks

Data seeding: minimal users (student, pi, catalyst), two labs, 10 papers.

## 3. Test Types
### 3.1 Unit & Component (Jest/React Testing Library)
- Buttons: focus rings, disabled state, keyboard activation
- HeatmapGrid: roving tabindex, arrow key nav, SR labels
- PaperCard: predictor bar accessibility text

### 3.2 API Contract (Dredd / Schemathesis)
- OpenAPI: `/api/v1/annotations`, `/api/v1/papers/{id}/save`
- GraphQL: schema validation and resolver shape

### 3.3 Integration
- Save action writes `interactions` + `rp_ledger`
- Annotation CRUD reflects in Reader panel
- Stream auto-posts after comment

### 3.4 E2E (Playwright)
**Critical paths:**
1) Sign-up → Save a paper → See RP in Log  
2) Create annotation → See in Reader, RP +5  
3) Catalyst “Seed Comment” → Stream shows post  
4) Evidence Map load → Vote snippet

### 3.5 Accessibility (axe + manual)
- Keyboard-only traversal of Home/Feed/Reader/Labs
- Screen reader: grid and card labels intelligible
- Color contrast verified (dark & light)

### 3.6 Performance
- p75 TTI < 2.5s (mid device); First-load JS < 200KB
- API p95: read < 300ms, write < 800ms
- Evidence Map response < 2s (cached)

### 3.7 Security
- Auth: JWT rotation tests; refresh misuse blocked
- RBAC: Catalyst/PI/Admin routes protected
- Rate limits: 429s emitted with correlation IDs
- OWASP checks (XSS, CSRF on state-changing endpoints)

### 3.8 AI/RAG Evaluation
- Golden set of (claim, expected citations)
- Precision@10, coverage, duplicate cite rate
- Prompt regression (promptfoo) – fail if metrics regress > tolerance
- Manual spot-checks for citation validity

## 4. Test Cases (condensed matrix)
| ID | Area | Case | Steps | Expected |
|---|---|---|---|---|
| A11Y‑01 | Heatmap | Keyboard nav | Arrow keys/Enter | Focus moves; digest opens |
| FEED‑02 | Save | ⌘/Ctrl+S | Press on card | 204 save; +3 RP |
| READER‑03 | Annotate | Create private | Select text, save | Annotation item + RP +5 |
| STREAM‑04 | Auto post | Comment | Post | Stream shows item |
| EVID‑05 | Evidence | Load snippets | Open tab | 10 items, each clickable |
| RAG‑06 | Voting | Upvote | Click ↑ | Vote persisted |
| PERF‑07 | API | p95 read | Load feed | < 300 ms |
| SEC‑08 | Rate | Burst comments | 20 in 1 min | 429 emitted |
| BILL‑09 | Pro | Entitlement | Access Q&A | Allowed for Pro only |

## 5. Acceptance by Level (traceability)
Map each Progress Tracker level to a pass/fail set of test IDs. Example:

- **Level 1:** A11Y‑01, LOG‑02, PERF‑07
- **Level 2:** FEED‑02, PERF‑07, ANAL‑10
- **Level 3:** READER‑03, A11Y‑11
- **Level 4:** STREAM‑04, SEC‑08

## 6. Reporting
- Daily: failing tests + owner + ETA
- Weekly: trend of failing IDs; flaky test list
- Release gates: all critical (P0/P1) pass; no new “high” vulnerabilities

## 7. Tools & Artifacts
- Playwright HTML reports (artifact on CI)
- Lighthouse JSON (artifact on CI)
- Datadog dashboards linked in release checklist
- Sentry releases with source maps

## 8. Exit Criteria
- All Level‑mapped tests pass
- SLOs green for 7 days on staging
- A11y score ≥ 95 (Lighthouse) + manual pass list filled
- Security scan clean (no high/critical)

**Checksum:** "cca2e4dd6bbb2450050f953d479aa83dd69ee54bb9b7ef4284d1ffa9835a002d"
