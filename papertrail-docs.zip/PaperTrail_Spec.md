# PaperTrail — Comprehensive Product & Technical Specification
**Version:** 3.0 • **Generated:** 2025-11-15T15:47:13.172892 UTC  
**Audience:** Engineering, Design, AI/ML, QA, DevOps, Security, Product  
**Scope:** This is the *single source of truth* for what to build, how it behaves, and how we know it’s done.

> **Principles**
> - Personal infrastructure first, social second.
> - Evidence broker, not truth engine.
> - Never host papers; cache metadata only.
> - Accessibility-by-default (WCAG AAA targets).

---

## 1. Vision & Outcomes
**Vision:** Turn passive, isolating reading into a measurable, collaborative workflow.  
**North Stars:**
- 40% of MAU maintain 7-day streaks.
- 1 in 10 saved papers has a public comment.
- 8% of MAU → Pro; 5% of active labs → Institutional.
- ARR targets: $250k (Year 1 Lab Tier), $1M (Year 2).

**Primary Personas**
- **Free Viewer:** discover & follow labs.
- **PhD Student (Primary):** maintain research habit, annotate, join dialogue.
- **PI:** coordinate lab, run journal club, track progress.

**Positioning:** *Your Research-Log, Your Lab’s Stream, Your Field’s Knowledge Graph.*

---

## 2. User Journeys & UI (Screen-by-Screen)
### 2.1 Research‑Log Dashboard (Home)
- **Purpose:** Habit loop (heatmap), day detail, lab activity sidebar.
- **Interactions:**
  - Keyboard: arrow keys navigate cells; Enter/Space opens day digest; `Tab` roves; role="grid".
  - Mobile: full-screen heatmap; swipe left on a day → “View Digest”.
- **A11y:**
  - `aria-label` on grid and cells (“2025‑11‑15: 12 RP, Emerald 10‑24”).
  - Live region announces digest result.
- **Acceptance:**
  - Heatmap renders 52×7, shows RP tiers: Mint (1–9), Emerald (10–24), Forest (25+).
  - Streak flame shows count, respects Rest Days.
  - Day panel lists interactions with timestamps.

### 2.2 Smart Feed
- **Components:** Filter chips, Paper cards, Engagement Predictor Bar, Quick Actions (Save, Annotate), Reading Room teaser.
- **Shortcuts:** ⌘/Ctrl+S (Save), ⌘/Ctrl+A (Annotate).
- **A11y:** Card `article` + SR text “Active debate, 34 comments”.
- **Acceptance:** Card fields (title, authors, venue, age) + predictor 0..1 mapped to % bar.

### 2.3 Intelligent Reader
- **Layout:** PDF (left, annotation lanes), Evidence Map/Q&A (right), Threaded notes (middle/right).
- **Visibility:** private (blue), lab (purple), public (green).
- **Evidence Map:** tabs: Supporting, Contextual; each item has up/down vote.
- **Ask the Paper (Pro):** grounded Q&A with citations (DOI/URL IDs only).
- **A11y:** Keyboard cycling through annotations; Evidence list is focusable; `aria-live` for new snippets.

### 2.4 Labs & Streams
- **Public Stream:** auto-posts (saves/comments/weekly digest), rate-limited manual posts (1/day, verified).
- **Follow:** Free viewers can follow up to 3 streams.
- **PI Dashboard:** aggregated heatmap (anonymizable), member progress table, reading room scheduler.

### 2.5 Catalyst Dashboard (Internal Tool)
- Sorted list: papers with 0 comments first.
- “Seed Comment” template with one-click post.
- Velocity gauge: “N more comments today to hit quota”.

---

## 3. Feature Pillars (Definitions & Rules of Play)
1. **Research‑Log**: private-by-default, 52-week heatmap, streak logic (≥5 RP/day), Rest Days.
2. **Engagement Engine**: RP ledger (view +1, save +3, annotate +5, public comment +7, reading room +25). No leaderboards.
3. **Discovery Engine**:
   ```
   Score = 0.4*Content + 0.3*NetworkVelocity + 0.2*Collaborative + 0.1*Recency
   ```
   - *Content:* keywords, citation sentiment.
   - *Velocity:* saves/hour, comment growth.
   - *Collaborative:* overlap in follows, lab proximity.
4. **Intelligent Reader**: Evidence broker (50% external data + 50% RAG). Human-in-the-loop votes on snippets.
5. **Lab Streams**: public activity feeds per lab.
6. **Partner‑Powered Reading Rooms**: attendance → +25 RP; transcript → Q&A tab.

---

## 4. Design System (Accessible-by-Default)
- **Typography:** Atkinson Hyperlegible (body), Inter (UI), base 16px (min).
- **Color tokens:** slate‑800 (#1e293b), emerald‑500 (#10b981), amber‑400 (#fbbf24). All text ≥ 7:1 contrast.
- **Interaction:** Focus rings (≥2px), target size ≥44×44 px, never rely on red/green alone.
- **Motion:** honors `prefers-reduced-motion`; no essential info encoded in motion.
- **Icons:** Feather (MIT); always include text labels.
- **Forms:** label+input+error trio; descriptive errors.

**Component Catalog (props & a11y):**
- Button, Link, IconButton, Badge, Chip (toggleable), Dialog (focus trap, escape), Tabs (roving tabindex), Tooltip (aria-describedby), PaperCard (SR text for predictor), HeatmapGrid (role=grid).

---

## 5. Data Model & Storage
### 5.1 Postgres (authoritative, ACID)
**Tables:** users, labs, lab_members, papers, interactions, annotations, comments, stream_posts, evidence_snippets, votes, follows, reading_rooms, rp_ledger.  
**Keys & Indexes:**  
- `interactions(user_id, timestamp desc)`, `comments(paper_id, created_at)`, `stream_posts(lab_id, timestamp)`, `votes(user_id, evidence_id)`
- See full SQL DDL in the starter kit and below excerpt:

```sql
-- Papers (metadata only; never host PDFs)
create table papers (
  id uuid primary key default uuid_generate_v4(),
  doi text unique,
  arxiv_id text unique,
  title text not null,
  abstract text,
  venue text,
  year int,
  url text,
  pdf_url text, -- only link
  source text not null,
  metadata jsonb not null default '{{}}'::jsonb,
  created_at timestamptz not null default now()
);
```

### 5.2 Neo4j (relationship graph)
Nodes: `User`, `Paper`, `Lab`  
Edges: `SAVED {at}`, `ANNOTATED {at, depth}`, `COMMENTED {at}`, `MEMBER_OF`, `FOLLOWS`  
**Example — No-comment papers:**
```cypher
MATCH (p:Paper)
WHERE NOT ( ()-[:COMMENTED]->(p) )
RETURN p LIMIT 50;
```

### 5.3 Qdrant (vector search for snippets)
Collection: `snippets` with payload `{ paper_id, citation_doi, source, snippet_text, created_at }` and vector embedding of `snippet_text`.

### 5.4 Redis (sessions, feature cache)
Cache per-user feed scores (TTL 1h), rate-limit counters, session data.

---

## 6. APIs & Contracts
### 6.1 Authentication & Sessions
- **OAuth 2.0 / OIDC** for SSO; **JWT** access (15m) + refresh (30d) rotation.
- Session revocation on password change or SSO logout.

### 6.2 GraphQL (Read-optimized)
Mounted at `/graphql`. Example:

```graphql
type Query { me: User, feed(limit: Int=10): [FeedCard!]!, researchLog(year: Int): [ResearchLogCell!]! }
type Mutation { savePaper(paperId: ID!): Boolean!, annotate(paperId: ID!, text: String!, visibility: String="private"): ID! }
```

### 6.3 REST (Action semantics)
- `POST /api/v1/papers/{paperId}/save` → 204
- `POST /api/v1/annotations` → 201 `{ id }`
- `GET /api/v1/interactions` → 200 `[Interaction]`

**Error format (REST & GraphQL extensions):**
```json
{ "error": { "code": "RATE_LIMIT", "message": "Try again later", "correlationId": "..." } }
```

### 6.4 Rate limiting
- IP+User buckets: 100 req/min (user), 300 req/min (IP) with burst; 429 on exceed.
- Public comment creation: 10/min per user; Catalyst seed: controlled via role.

### 6.5 Webhooks (Partner Reading Rooms)
- `reading_room.attended` → create interaction (action=reading_room), award +25 RP.

---

## 7. Integrations (Polite Crawling & Caching)
- **NCBI E-utilities (PubMed):** 3 r/s (10 with key), cache 7 days.
- **Semantic Scholar:** 100 r/s, cache 30 days.
- **arXiv:** 1 req / 3s, cache 7 days.
- **OpenAlex/CrossRef:** per-provider limits, cache 7–30 days.
- **PDFs:** link only; load client-side; respect robots and ToS.

**Retry policy:** exponential backoff (jitter), max 3 retries; dead-letter queue for failures.

---

## 8. AI / RAG “Evidence Broker”
### 8.1 Pipeline
1. **Claim extraction:** NER on highlighted text (scispaCy).  
2. **Query expansion:** LLM generates 3–5 queries (no truth claims).  
3. **Retrieval:** Semantic Scholar (citation context), OpenAlex (similar work), internal graph (high-discussion papers).  
4. **Ranking:** LightGBM ranker trained on `votes`.  
5. **Synthesis:** Grounded summary with **explicit citations** (DOI/URL IDs only).

### 8.2 Models
- LLM: GPT‑4o‑mini initially; plan for Llama 3.3 70B self-hosting later.
- Embeddings: `text-embedding-3-small` → switch to `all-MiniLM-L6-v2` later.
- Ranker: LightGBM.

### 8.3 Evaluation
- Precision@10 ≥ 0.7; Upvote rate ≥ 40%; CTR on cited items ≥ 60%.
- Prompt regression with promptfoo; golden sets per launch field.

### 8.4 Safety & UX
- Strict “evidence broker” phrasing; no authoritative claims.
- Always show sources; allow “flag snippet” for misleading passages.

---

## 9. Discovery Engine (Online Ranking)
**Score = 0.4 Content + 0.3 NetworkVelocity + 0.2 Collaborative + 0.1 Recency**  
- **Content:** TF‑IDF/embeddings on title+abstract; sentiment from S2 contexts.  
- **NetworkVelocity:** moving average of saves/hour, comment deltas.  
- **Collaborative:** Jaccard overlap of followed labs; nearest-neighbor in user‑paper space.  
- **Recency:** monotonic decay function (e.g., half-life 7 days).

Feature calc batched every 15 min (Redis cached).

---

## 10. Security, Privacy, Compliance
- RBAC roles: `student`, `pi`, `catalyst`, `admin`; lab‑scoped permissions.
- JWT short‑lived; refresh rotation; IP allowlist for admin.
- PII: email, name—minimize; encrypt in transit; least‑privilege DB access.
- Data deletion: hard‑delete annotations/comments upon user request; retain aggregate counts only.
- Audit logs: auth events, role changes, data exports.
- Abuse/misinfo: rate limits, moderation queue, verified lab posting.

---

## 11. Observability & SLOs
- **APM:** Datadog (traces, spans); **Errors:** Sentry; **Logs:** structured JSON.
- **Key metrics:** `rp_earned`, `comment_velocity`, `feed_click_through`, `evidence_upvote_rate`, `streak_active_users`.
- **SLOs:** p95 API < 300 ms (read), < 800 ms (write); error rate < 0.5%/hour; availability 99.9%.
- **Dashboards:** Product (habits, density), Infra (CPU/mem/IO), AI (RAG evals).

---

## 12. Performance Budgets
- Web First Load JS < 200KB; p75 TTI < 2.5s on mid‑range mobile.
- Evidence Map results < 2s for top 10 snippets (cached if possible).
- PDF Viewer interactions < 50ms for annotation create/select.

---

## 13. DevOps & Environments
- **Frontend:** Vercel; **Backend:** AWS ECS Fargate; **DB:** Neon (branching).  
- Secrets: AWS Secrets Manager; never commit `.env` to repo.  
- Preview deployments per PR (isolated Neon branch).  
- Blue/Green or rolling with health checks `/healthz`.

---

## 14. CI/CD Gates
- Unit > 80% (core), a11y/Lighthouse ≥ 95, type-check clean.  
- Contract tests: GraphQL & OpenAPI.  
- Prompt regression (RAG) must pass golden set deltas.  
- E2E smoke (Playwright) across top flows.

---

## 15. Monetization & Entitlements
- Tiers: Free, Pro ($5/mo), Lab ($150/mo, 1–15 users), Institutional ($15k+/yr).  
- Entitlements map: streams visible, annotation visibilities, AI quotas (e.g., Evidence Map citations per day).  
- Billing events: seat add/remove, proration, invoices.

---

## 16. Product Analytics (Event Taxonomy)
- `paper_saved` (paper_id, source, position), `annotation_created` (visibility, length), `comment_posted` (lab_id?), `stream_followed`, `reading_room_attended`, `evidence_voted` (vote=±1), `ask_paper_used`.  
- All events include `user_id`, `timestamp`, `session_id`, `screen`.

---

## 17. Roadmap & Milestones
- **Phase 1 (M1–6):** Research‑Log, Save, Private annotations, PubMed integration, ELIA only, catalysts hired. Goal: 500 users with 30‑day streaks.
- **Phase 2 (M7–12):** Labs tab, Public comments, Following, Evidence Map (S2 only), launch Lab Tier; 50 labs; 3k total users.
- **Phase 3 (M13–18):** Pro with Ask the Paper (RAG), votes live; 1k Pro users; 100 labs.
- **Phase 4 (M19–24):** Institutional (SSO, API, Claim Tracker), Synthesize Library; 5 institutional; 10k users.

---

## 18. Acceptance Criteria by Module (DoD)
- **Research‑Log:** heatmap operable by keyboard; streak logic with Rest Days; RP totals match ledger.
- **Feed:** predictor bar shows %; Save/Annotate shortcuts work; filters persist.
- **Reader:** annotations CRUD; visibility respected; Evidence Map shows 10 citations, each clickable and votable.
- **Lab Streams:** auto‑posts on save/comment; follow limit enforced for Free; PI dashboard aggregates.
- **Reading Rooms:** SSO works; attendance recorded; +25 RP ledgered; transcript binds to Q&A.
- **AI:** citations always included; no hallucinated IDs in tests; upvote/downvote persisted.
- **A11y:** axe & Lighthouse clean (≥95); manual checks pass (keyboard and SR).

---

## 19. Risk Register & Mitigations
- Empty Room → catalysts + niche focus; metric: 50% of new users comment within 7 days.
- AI Over‑promise → evidence framing; metric: >40% upvote.
- Partner Dependency → native reading room by Month 18; metric: <30% minutes off‑site by M12.
- Price Mismatch → tier calibration; metric: 200 lab subs by Year 1.

---

## 20. Glossary
- **RP:** Research Points (habit currency).  
- **Evidence Map:** citation‑grounded snippets ranked by usefulness.  
- **Catalyst:** staff seeding early conversation density.

---

**Appendix A — Example Payloads**

**Save Paper (REST)**
```http
POST /api/v1/papers/8ed1/save
204 No Content
X-Correlation-Id: 7c1f...
```

**GraphQL feed query**
```graphql
query { feed(limit: 10) { paper { id title } engagementPrediction } }
```

**Appendix B — ADR Index (seed)**
- ADR‑001: Never host PDFs — metadata only.
- ADR‑002: Modular monolith in Year 1, extract services Year 2.
- ADR‑003: Evidence broker posture, never “truth engine”.

---

**Checksum:** "46fa759dcdcfd8767286a9548346e5436aae7174fffd195da726e1ea154623f3"
